package MavenSpring.Springdemo;

public interface Sim {
 public void typeOfSim();
 public void dataTypeOfSim();
 
 
}
