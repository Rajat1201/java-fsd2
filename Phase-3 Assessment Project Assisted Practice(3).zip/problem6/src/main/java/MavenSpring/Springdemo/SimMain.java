package MavenSpring.Springdemo;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class SimMain {
public static void main(String[] a)
{
	ApplicationContext ac=new ClassPathXmlApplicationContext("Spring.xml");
	Airtel airtel=ac.getBean(Airtel.class);
	airtel.setDataStrength("airtel is having good strength");
	
	Idea idea=ac.getBean(Idea.class);
	idea.display();

	
	airtel.dataTypeOfSim();
	airtel.typeOfSim();
	airtel.getDataStrength();
	/*Airtel airtel=new Airtel();
	airtel.dataTypeOfSim();
	airtel.typeOfSim();*/
}
}
