package MavenSpring.Springdemo;

public class Airtel implements Sim{
 private String dataStrength;
	public String getDataStrength() {
		return dataStrength;
	}
	
	public void setDataStrength(String dataStrength) {
		this.dataStrength=dataStrength;
	}
	public void typeOfSim()
	{
		System.out.println("Airtel is the Sim");
	}
	 public void dataTypeOfSim()
	 {
		 System.out.println("it has 5g access");
	 }
	 
}
