package problem5;

import org.junit.jupiter.api.DynamicTest;
import org.junit.jupiter.api.TestFactory;
import org.junit.jupiter.api.function.Executable;

import java.util.Arrays;
import java.util.Collection;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.DynamicTest.dynamicTest;

public class DynamicTestEx{

    @TestFactory
    Collection<DynamicTest> dynamicTests() {
        return Arrays.asList(
                dynamicTest("Test Addition", () -> {
                    int result = Calculator.add(2, 3);
                    assertEquals(5, result);
                }),
                dynamicTest("Test Subtraction", () -> {
                    int result = Calculator.subtract(5, 2);
                    assertEquals(3, result);
                })
        );
    }

    static class Calculator {
        static int add(int a, int b) {
            return a + b;
        }

        static int subtract(int a, int b) {
            return a - b;
        }
    }
}