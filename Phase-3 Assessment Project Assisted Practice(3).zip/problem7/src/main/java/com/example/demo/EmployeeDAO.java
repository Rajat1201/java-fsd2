package com.example.demo;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class EmployeeDAO {

	//interface EmpRepo extends JpaRepository<Employee,Integer>  =>all the predefined crud methods are brought into the EmpRepo
	@Autowired   //used to generate a refernce to the object automatically 
	EmpRepo repo;
	
	//insert operation 
	public Employee insert(Employee e) {
		return repo.save(e);
	}
	
	
	//list of inserts 
	public List<Employee> insertall(List<Employee> e){
		return repo.saveAll(e);
	}
	
	
}
