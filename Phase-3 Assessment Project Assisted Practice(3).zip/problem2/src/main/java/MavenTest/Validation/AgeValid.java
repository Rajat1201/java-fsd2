package MavenTest.Validation;


public class AgeValid {

	public String validateAge(int age) {
		if(age>=18) {
			return "right to vote";
		}
		else {
			return "no right to vote";
		}
	}
	
}

