package MavenTest.PrimeValidation;

import static org.junit.Assert.assertEquals;

import org.junit.Test;

public class PrimeTest {
	//@Test - test method
		@Test
		public void test1() {
			CheckPrime check=new CheckPrime();
			
		//	 expected value  actual value
			  assertEquals("is a prime number",check.isPrime(2));
		}

		
		@Test
		public void test2() {
			CheckPrime check=new CheckPrime();
			
			//	 expected value  actual value
				  assertEquals("is not a prime number",check.isPrime(8));
		}
	}