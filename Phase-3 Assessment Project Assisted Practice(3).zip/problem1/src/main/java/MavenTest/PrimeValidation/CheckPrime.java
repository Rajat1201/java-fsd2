package MavenTest.PrimeValidation;

public class CheckPrime {
	public String isPrime(int num) {
    boolean flag = false;
    for (int i = 2; i <= num / 2; ++i) {
      if (num % i == 0) {
        flag = true;
        break;
      }
    }

    if (!flag)
      return  "is a prime number";
    else
      return "is not a prime number";
  }}

