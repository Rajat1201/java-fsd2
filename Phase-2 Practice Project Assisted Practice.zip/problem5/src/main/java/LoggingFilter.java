import java.io.IOException;
import javax.servlet.*;
import javax.servlet.annotation.WebFilter;
import javax.servlet.http.HttpServletRequest;

@WebFilter("/*")
public class LoggingFilter implements Filter {

    public void init(FilterConfig filterConfig) throws ServletException {
      
    }

   
    public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain)
            throws IOException, ServletException {
        HttpServletRequest httpRequest = (HttpServletRequest) request;
        
        
        System.out.println("Request received - Method: " + httpRequest.getMethod()
                + ", URL: " + httpRequest.getRequestURL());
        
       
        chain.doFilter(request, response);
    }

   
    public void destroy() {
       
    }
}