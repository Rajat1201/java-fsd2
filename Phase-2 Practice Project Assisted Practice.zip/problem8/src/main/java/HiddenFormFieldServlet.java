import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@WebServlet("/HiddenFormFieldServlet")
public class HiddenFormFieldServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
    	response.setContentType("text/html");
        PrintWriter out = response.getWriter();

      
        HttpSession session = request.getSession();

        
        Integer counter = (Integer) session.getAttribute("counter");
        if (counter == null) {
       
            counter = 1;
        } else {
           
            counter++;
        }

        
        session.setAttribute("counter", counter);

       
        String htmlCode = "<!DOCTYPE html>\n" +
                "<html>\n" +
                "<head>\n" +
                "    <title>Session Tracking using Hidden Form Fields</title>\n" +
                "</head>\n" +
                "<body>\n" +
                "    <h2>Session Tracking using Hidden Form Fields</h2>\n" +
                "    <p>Counter: " + counter + "</p>\n" +
                "    <form action='HiddenFormFieldServlet' method='post'>\n" +
                "        <input type='hidden' name='counter' value='" + counter + "'>\n" +
                "        <input type='submit' value='Increment'>\n" +
                "    </form>\n" +
                "</body>\n" +
                "</html>";

        out.println(htmlCode);
}
    
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        doGet(request, response);
    }
}