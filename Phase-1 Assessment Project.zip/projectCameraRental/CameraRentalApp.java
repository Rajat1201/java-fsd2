package projectCameraRental;
import java.util.*;

class Camera {
    private String brand;
    private String model;
    private double rentalAmount;
    private boolean available;

    public Camera(String brand, String model, double rentalAmount) {
        this.brand = brand;
        this.model = model;
        this.rentalAmount = rentalAmount;
        this.available = true;
    }

    public String getBrand() {
        return brand;
    }

    public String getModel() {
        return model;
    }

    public double getRentalAmount() {
        return rentalAmount;
    }

    public boolean isAvailable() {
        return available;
    }

    public void setAvailable(boolean available) {
        this.available = available;
    }
}

class User {
    private String username;
    private String password;
    private double walletAmount;
    private List<Camera> rentedCameras;

    public User(String username, String password) {
        this.username = username;
        this.password = password;
        this.walletAmount = 0.0;
        this.rentedCameras = new ArrayList<>();
    }

    public String getUsername() {
        return username;
    }

    public String getPassword() {
        return password;
    }

    public double getWalletAmount() {
        return walletAmount;
    }

    public void setWalletAmount(double walletAmount) {
        this.walletAmount = walletAmount;
    }

    public List<Camera> getRentedCameras() {
        return rentedCameras;
    }

    public void rentCamera(Camera camera) {
        if (camera.isAvailable()) {
            if (walletAmount >= camera.getRentalAmount()) {
                rentedCameras.add(camera);
                walletAmount -= camera.getRentalAmount();
                camera.setAvailable(false);
                System.out.println("Camera rented successfully!");
            } else {
                System.out.println("INSUFFICIENT WALLET BALANCE:Please deposit more funds.");
            }
        } else {
            System.out.println("CAMERA IS NOT AVAILABLE FOR RENT.");
        }
    }
}

public class CameraRentalApp {
    private static List<Camera> cameraList = new ArrayList<>();
    private static User currentUser;

    public static void main(String[] args) {
        
        showWelcomeScreen();

       
        performLogin();

        addPreExistingCameras();
        
        showMainMenu();
    }

    private static void showWelcomeScreen() {
        System.out.println("Welcome to Camera Rental App");
        System.out.println("Developed by RAJAT SHARMA");
        System.out.println();
    }

    private static void performLogin() {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter your username: ");
        String username = scanner.nextLine();
        System.out.print("Enter your password: ");
        String password = scanner.nextLine();

        
        if (isValidUser(username, password)) {
            
            currentUser = new User(username, password);
        } else {
            System.out.println("Invalid username or password. Exiting the application.");
            System.exit(0);
        }
    }

    private static boolean isValidUser(String username, String password) {
        if (username.equals("admin") && password.equals("password")) {
            return true; 
        }
    
        return false;
    }

    private static void showMainMenu() {
        Scanner scanner = new Scanner(System.in);
        int choice;

        do {
            System.out.println();
            System.out.println("----- Main Menu -----");
            System.out.println("1. My Camera");
            System.out.println("2. Rent a Camera");
            System.out.println("3. View All Cameras");
            System.out.println("4. My Wallet");
            System.out.println("5. EXIT");
            System.out.print("Enter your choice: ");
            choice = scanner.nextInt();

            switch (choice) {
                case 1:
                    showMyCameraMenu();
                    break;
                case 2:
                    rentCamera();
                    break;
                case 3:
                    viewAllCameras();
                    break;
                case 4:
                    showWalletMenu();
                    break;
                case 5:
                    System.out.println("Thank you for using the Camera Rental App. Goodbye!");
                    break;
                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        } while (choice != 5);
    }

    private static void showMyCameraMenu() {
        Scanner scanner = new Scanner(System.in);
        int choice;

        do {
            System.out.println();
            System.out.println("----- My Camera Menu -----");
            System.out.println("1. Add Camera");
            System.out.println("2. Remove Camera");
            System.out.println("3. View My Cameras");
            System.out.println("4. Go to Previous Menu");
            System.out.print("Enter your choice: ");
            choice = scanner.nextInt();

            switch (choice) {
                case 1:
                    addCamera();
                    break;
                case 2:
                    removeCamera();
                    break;
                case 3:
                    viewMyCameras();
                    break;
                case 4:
                    
                    break;
                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        } while (choice != 4);
    }

    private static void addCamera() {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Enter the brand of the camera: ");
        String brand = scanner.nextLine();
        System.out.print("Enter the model of the camera: ");
        String model = scanner.nextLine();
        System.out.print("Enter the per-day rental amount (in INR): ");
        double rentalAmount = scanner.nextDouble();

        Camera camera = new Camera(brand, model, rentalAmount);
        cameraList.add(camera);
        System.out.println("Camera added successfully!");
    }

    private static void removeCamera() {
        Scanner scanner = new Scanner(System.in);
    
        System.out.print("Enter the index of the camera to remove: ");
        int index;
        try {
            index = Integer.parseInt(scanner.nextLine());
        } catch (NumberFormatException e) {
            System.out.println("Invalid input. Please enter a valid camera index.");
            return;
        }
    
        List<Camera> rentedCameras = currentUser.getRentedCameras();
        if (index >= 1 && index <= rentedCameras.size()) {
            Camera camera = rentedCameras.get(index - 1);
            if (!camera.isAvailable()) {
                rentedCameras.remove(camera);
                System.out.println("Camera removed successfully!");
            } else {
                System.out.println("Cannot remove an available camera.");
            }
        } else {
            System.out.println("Invalid camera index.");
        }
    }

    private static void viewMyCameras() {
        System.out.println();
        System.out.println("----- My Cameras -----");

        if (currentUser.getRentedCameras().isEmpty()) {
            System.out.println("No cameras rented.");
        } else {
            int count = 1;
            for (Camera camera : currentUser.getRentedCameras()) {
                System.out.println(count + ". " + camera.getBrand() + " " + camera.getModel());
                count++;
            }
        }
    }

    private static void rentCamera() {
        Scanner scanner = new Scanner(System.in);

        System.out.println();
        System.out.println("----- Available Cameras -----");

        if (cameraList.isEmpty()) {
            System.out.println("No cameras available for rent.");
        } else {int count = 1;
            for (Camera camera : cameraList) {
                String availability = camera.isAvailable() ? "Available" : "Rented";
                System.out.println(count + ". " + camera.getBrand() + " " + camera.getModel() + " (Rent: " + camera.getRentalAmount() + " INR per day) - " + availability);
                count++;
            }

            System.out.print("Enter the index of the camera to rent: ");
int index;
try {
    index = Integer.parseInt(scanner.nextLine());
} catch (NumberFormatException e) {
    System.out.println("Invalid input. Please enter a valid camera index.");
    return;
}

if (index >= 1 && index <= cameraList.size()) {
    Camera camera = cameraList.get(index - 1);
    currentUser.rentCamera(camera);
} else {
    System.out.println("Invalid camera index.");
}
        }
    }

    
    
    private static void viewAllCameras() {
        System.out.println();
        System.out.println("----- All Cameras -----");
        System.out.println("INDEX\tBRAND\t\tMODEL\t\t\tPRICE/DAY\tSTATUS");
    
        if (cameraList.isEmpty()) {
            System.out.println("No cameras available at the moment.");
        } else {
            int count = 1;
            for (Camera camera : cameraList) {
                String availability = camera.isAvailable() ? "Available" : "Rented";
                System.out.printf("%-6d\t%-15s\t%-20s\t%.2f\t\t%-8s\n", count, camera.getBrand(), camera.getModel(), camera.getRentalAmount(), availability);
                count++;
            }
        }
    }
    
    
    
    private static void addPreExistingCameras() {
        Camera nikonCamera1 = new Camera("Nikon", "D850", 1000.0);
        cameraList.add(nikonCamera1);
    
        Camera nikonCamera2 = new Camera("Nikon", "Z7 II", 1200.0);
        cameraList.add(nikonCamera2);
    
        Camera samsungCamera1 = new Camera("Samsung", "NX1", 800.0);
        cameraList.add(samsungCamera1);
    
        Camera samsungCamera2 = new Camera("Samsung", "NX500", 700.0);
        cameraList.add(samsungCamera2);
    
        Camera samsungCamera3 = new Camera("Samsung", "Galaxy Camera", 600.0);
        cameraList.add(samsungCamera3);
    }
    

    private static void showWalletMenu() {
        Scanner scanner = new Scanner(System.in);
        int choice;

        do {
            System.out.println();
            System.out.println("----- Wallet Menu -----");
            System.out.println("1. Add Funds");
            System.out.println("2. View Balance");
            System.out.println("3. Go to Previous Menu");
            System.out.print("Enter your choice: ");
            choice = scanner.nextInt();

            switch (choice) {
                case 1:
                    addFunds();
                    break;
                case 2:
                    viewBalance();
                    break;
                case 3:
                  
                    break;
                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        } while (choice != 3);
    }

    private static void addFunds() {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Enter the amount to deposit: ");
        double amount = scanner.nextDouble();
        currentUser.setWalletAmount(currentUser.getWalletAmount() + amount);
        System.out.println("Funds deposited successfully!");
    }

    private static void viewBalance() {
        System.out.println();
        System.out.println("----- Wallet Balance -----");
        System.out.println("Current balance: " + currentUser.getWalletAmount() + " INR");
    }
}