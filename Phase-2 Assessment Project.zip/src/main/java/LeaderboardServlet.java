import java.io.IOException;
import java.util.List;
import java.util.ArrayList;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import project.UserDAO;
import project.UserScore;
import project.Score;
import project.User;
public class LeaderboardServlet extends HttpServlet {
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
     
        List<UserScore> leaderboard = getLeaderboard();

       
        request.setAttribute("leaderboard", leaderboard);

      
        request.getRequestDispatcher("LeaderBoard.jsp").forward(request, response);
    }

    private List<UserScore> getLeaderboard() {

        List<UserScore> leaderboard = new ArrayList<>();

     
        UserDAO userDAO = new UserDAO(null);

        int users = userDAO.getTotalUsers();

        for (UserScore user : users) {
           
            int scores = UserScore.getUserScore(user.getId());

         
            int totalScore = calculateTotalScore(scores);

            UserScore userScore = new UserScore(user.getUsername(), totalScore);

           
            leaderboard.add(userScore);
        }

        leaderboard.sort((u1, u2) -> Integer.compare(u2.getTotalScore(), u1.getTotalScore()));

        return leaderboard;
    }

    private int calculateTotalScore(int scores) {
        int totalScore = 0;
        for (Score score : scores) {
            totalScore += score.getValue();
        }
        return totalScore;
    }
    }
