package project;

public class Score {
	private int Value;
    private String quizName;
    private int score;

    public Score(String quizName, int score) {
        this.quizName = quizName;
        this.score = score;
    }

    public String getQuizName() {
        return quizName;
    }

    public int getScore() {
        return score;
    }

	public int getValue() {
		
		return Value;
	}
}