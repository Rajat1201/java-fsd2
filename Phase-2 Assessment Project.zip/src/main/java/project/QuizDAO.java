package project;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class QuizDAO {
    private Connection connection;

    public QuizDAO(Connection connection) {
        this.connection = connection;
    }

   

	public int getTotalQuiz() {
        int total = 0;
        try {
            PreparedStatement statement = connection.prepareStatement("SELECT COUNT(*) FROM quizes");
            ResultSet resultSet = statement.executeQuery();
            if (resultSet.next()) {
                total = resultSet.getInt(1);
            }
            resultSet.close();
            statement.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return total;
    }
    public void saveQuiz(String quizName, String[] selectedQuestions) {
	        try {
	         
	            PreparedStatement statement = connection.prepareStatement("INSERT INTO quizzes (quiz_name) VALUES (?)");
	            statement.setString(1, quizName);
	            statement.executeUpdate();
	            statement.close();

	        
	            int quizId = getQuizId(quizName);

	            
	            for (String questionId : selectedQuestions) {
	                PreparedStatement questionStatement = connection.prepareStatement("INSERT INTO quiz_questions (quiz_id, question_id) VALUES (?, ?)");
	                questionStatement.setInt(1, quizId);
	                questionStatement.setInt(2, Integer.parseInt(questionId));
	                questionStatement.executeUpdate();
	                questionStatement.close();
	            }
	        } catch (SQLException e) {
	            e.printStackTrace();
	        }
	    }

	    private int getQuizId(String quizName) {
	        int quizId = 0;
	        try {
	            PreparedStatement statement = connection.prepareStatement("SELECT quiz_id FROM quizzes WHERE quiz_name = ?");
	            statement.setString(1, quizName);
	            ResultSet resultSet = statement.executeQuery();
	            if (resultSet.next()) {
	                quizId = resultSet.getInt("quiz_id");
	            }
	            resultSet.close();
	            statement.close();
	        } catch (SQLException e) {
	            e.printStackTrace();
	        }
	        return quizId;
	    }
	   

	    
	    
	    }
	
