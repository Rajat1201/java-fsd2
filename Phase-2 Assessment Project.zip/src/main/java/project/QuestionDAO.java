package project;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class QuestionDAO {
    private Connection connection;

    public QuestionDAO(Connection connection) {
        this.connection = connection;
    }

    public QuestionDAO() {
		
	}

	public int getTotalQuestions() {
        int total = 0;
        try {
            PreparedStatement statement = connection.prepareStatement("SELECT COUNT(*) FROM questions");
            ResultSet resultSet = statement.executeQuery();
            if (resultSet.next()) {
                total = resultSet.getInt(1);
            }
            resultSet.close();
            statement.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return total;
    }
	public void saveQuestion(Question question) {
        try {
            PreparedStatement statement = connection.prepareStatement("INSERT INTO questions (question, answer) VALUES (?, ?)");
            statement.setString(1, question.getQuestion());
            statement.setString(2, question.getAnswer());
            statement.executeUpdate();
            statement.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }}
}