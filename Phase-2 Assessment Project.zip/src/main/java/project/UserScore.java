package project;



public class UserScore {
    private int id;
	private String username;
    private int totalScore;
    public static int Score;

    public UserScore(String username, int totalScore) {
        this.username = username;
        this.totalScore = totalScore;
    }

    public String getUsername() {
        return username;
    }

    public int getTotalScore() {
        return totalScore;
    }

	public int getId() {
		
		return id;
	}

	public static int getUserScore(int id) {
		
		return Score;
	}

	
}