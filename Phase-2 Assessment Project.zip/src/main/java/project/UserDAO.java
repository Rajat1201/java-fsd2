package project;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Map;;
public class UserDAO {
   
    
	private static final String DB_URL = "jdbc:mysql://localhost:3306/db1";
	private static final String DB_USERNAME = "root";
	private static final String DB_PASSWORD = "dgsdg454FF@";
	private Map<String, User> userMap;

    	private Connection connection;

        public UserDAO(Connection connection) {
            this.connection = connection;
        userMap = new HashMap<String, User>();
        User user1 = new User("admin", "password");
        User user2 = new User("rajat", "secret");
        User user3 = new User("parul", "pass123");
        userMap.put(user1.getUsername(), user1);
        userMap.put(user2.getUsername(), user2);
        userMap.put(user3.getUsername(), user3);
        
        
        }

        public int getTotalUsers() {
            int total = 0;
            try {
                PreparedStatement statement = connection.prepareStatement("SELECT COUNT(*) FROM users");
                ResultSet resultSet = statement.executeQuery();
                if (resultSet.next()) {
                    total = resultSet.getInt(1);
                }
                resultSet.close();
                statement.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
            return total;
        
    }
   
    public User getUserByUsername(String username) {
        return userMap.get(username);
    }
    

    public void saveUser(User user) {
        
        Connection connection = null;
        PreparedStatement statement = null;
        
        try {
          
            connection = DriverManager.getConnection(DB_URL, DB_USERNAME, DB_PASSWORD);
            
           
            String sql = "INSERT INTO users (username, password) VALUES (?, ?)";
            
          
            statement = connection.prepareStatement(sql);
            
            
            statement.setString(1, user.getUsername());
            statement.setString(2, user.getPassword());
            
            
            statement.executeUpdate();
            
        } catch (SQLException e) {
            
            e.printStackTrace();
        } finally {
           
            try {
                if (statement != null) {
                    statement.close();
                }
                if (connection != null) {
                    connection.close();
                }
            } catch (SQLException e) {
                e.printStackTrace();
            
            }}}
    public void saveQuiz(Quiz q) throws SQLException {
        Connection connection = null;
        PreparedStatement statement = null;

        
            connection = DriverManager.getConnection(DB_URL, DB_USERNAME, DB_PASSWORD);

           
            String query = "INSERT INTO quizzes (quiz_name) VALUES (?)";
            statement = connection.prepareStatement(query);
            statement.setString(1, q.getQuizName());

            
            statement.executeUpdate();

           
            saveQuizQuestions(q, connection);
        } 
    

    private void saveQuizQuestions(Quiz quiz, Connection connection) throws SQLException {
        // Prepare the SQL statement
        String query = "INSERT INTO quiz_questions (quiz_id, question_id) VALUES (?, ?)";
        PreparedStatement statement = connection.prepareStatement(query);

        int quizId = getGeneratedQuizId(connection);

       
        for (Question question : quiz.getQuestions()) {
            statement.setInt(1, quizId);
            statement.setString(2, question.getQuestion());
            statement.executeUpdate();
        }

       
    }

    private int getGeneratedQuizId(Connection connection) throws SQLException {
      
        String query = "SELECT LAST_INSERT_ID() AS quiz_id";
        PreparedStatement statement = connection.prepareStatement(query);
        int quizId = -1;

        
        ResultSet resultSet = statement.executeQuery();
        if (resultSet.next()) {
            quizId = resultSet.getInt("quiz_id");
        }

        

        return quizId;
    }


}