import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import project.UserDAO;
import project.QuizDAO;
import project.QuestionDAO;
public class AdminDashboardServlet extends HttpServlet {
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
       
        if (isAdminAuthenticated(request)) {
            
            int totalQuiz = getTotalQuiz();
            int totalQuestions = getTotalQuestions();
            int totalUsers = getTotalUsers();

           
            request.setAttribute("totalQuiz", totalQuiz);
            request.setAttribute("totalQuestions", totalQuestions);
            request.setAttribute("totalUsers", totalUsers);

       
            request.getRequestDispatcher("Dashboard.jsp").forward(request, response);
        } else {
       
            response.sendRedirect("login.jsp");
        }
    }

    private boolean isAdminAuthenticated(HttpServletRequest request) {
     
        HttpSession session = request.getSession(false);
        return session != null && session.getAttribute("username").equals("admin");
    }

    private int getTotalQuiz() {
    
        QuizDAO quizDAO = new QuizDAO(null);
        return quizDAO.getTotalQuiz();
    }

    private int getTotalQuestions() {
       
        QuestionDAO questionDAO = new QuestionDAO();
        return questionDAO.getTotalQuestions();
    }

    private int getTotalUsers() {
        UserDAO userDAO = new UserDAO(null);
        return userDAO.getTotalUsers();
    }
}