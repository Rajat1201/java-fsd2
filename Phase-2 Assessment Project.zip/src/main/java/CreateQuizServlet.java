import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import project.Quiz;

import project.UserDAO;
public class CreateQuizServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String quizName = request.getParameter("quizName");
        String[] selectedQuestions = request.getParameterValues("selectedQuestions");

    
        saveQuiz(quizName, selectedQuestions);

        
        request.setAttribute("message", "Quiz created successfully!");
        request.getRequestDispatcher("QuizList.jsp").forward(request, response);
    }

    private void saveQuiz(String quizName, String[] selectedQuestions) {
    	UserDAO quizDAO = new UserDAO(null);
        UserDAO q = new UserDAO(null);
        UserDAO.saveQuiz(q);
    }
}