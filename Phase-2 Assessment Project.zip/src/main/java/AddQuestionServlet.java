import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import project.QuestionDAO;
import project.Question;
public class AddQuestionServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String question = request.getParameter("question");
        String answer = request.getParameter("answer");

        
        saveQuestion(question, answer);

    
        request.setAttribute("message", "Question added successfully!");
        request.getRequestDispatcher("QuestionList.jsp").forward(request, response);
    }

    private void saveQuestion(String question, String answer) {
        QuestionDAO questionDAO = new QuestionDAO();
        Question newQuestion = new Question(question, answer);
        questionDAO.saveQuestion(newQuestion);
    }
}