package problem9;

import java.util.LinkedList;
import java.util.Queue;
import java.util.Scanner;

public class QueueEx {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

       
        Queue<Integer> queue = new LinkedList<>();

        
        System.out.println("Enter the number of elements to add in queue:");
        int n = scanner.nextInt();
        System.out.println("Enter " + n + " elements to add in queue:");
        for (int i = 0; i < n; i++) {
            int element = scanner.nextInt();
            queue.add(element);
        }

      
        System.out.println("Enter the number of elements to remove from queue:");
        int m = scanner.nextInt();
        System.out.println("Dequeued elements from the queue:");
        for (int i = 0; i < m; i++) {
            int element = queue.remove();
            System.out.println(element);
        }

        scanner.close();
        
    }}