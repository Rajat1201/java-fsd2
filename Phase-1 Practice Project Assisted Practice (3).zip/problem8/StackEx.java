package problem8;
import java.util.Scanner;
import java.util.Stack;

public class StackEx {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

       
        Stack<Integer> stack = new Stack<>();

        
        System.out.println("Enter the number of elements to push into the stack:");
        int n = scanner.nextInt();
        System.out.println("Enter " + n + " elements to push :");
        for (int i = 0; i < n; i++) {
            int element = scanner.nextInt();
            stack.push(element);
        }

        
        System.out.println("Enter the number of elements to pop out from the stack:");
        int m = scanner.nextInt();
        System.out.println("Popped elements from the stack:");
        for (int i = 0; i < m; i++) {
            int element = stack.pop();
            System.out.println(element);
        }

        scanner.close();}
}

