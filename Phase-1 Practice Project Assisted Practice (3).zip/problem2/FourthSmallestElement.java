package problem2;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Scanner;

public class FourthSmallestElement {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        
        System.out.print("Enter the size of the list: ");
        int n = sc.nextInt();

        List<Integer> list = new ArrayList<>();

       
        System.out.println("Enter the elements of the list:");
        for (int i = 0; i < n; i++) {
            list.add(sc.nextInt());
        }

       
        Collections.sort(list);
        int fourthSmallest = list.get(3);

       
        System.out.println("The 4th smallest element in the list are: " + fourthSmallest);
    

}}
