package problem5;
import java.util.LinkedList;
import java.util.Scanner;


public class SinglyLinkedList {
	

	
	    public static void main(String[] args) {
	        Scanner sc = new Scanner(System.in);

	        
	        LinkedList<Integer> list = new LinkedList<Integer>();

	        
	        System.out.print("Enter the size of the linked list: ");
	        int n = sc.nextInt();

	        System.out.println("Enter the elements of the linked list:");
	        for (int i = 0; i < n; i++) {
	            int data = sc.nextInt();
	            list.add(data);
	        }

	       
	        System.out.print("Enter the key to be deleted: ");
	        int key = sc.nextInt();

	        
	        list.removeFirstOccurrence(key);

	        System.out.println("Linked List: " +list);
	        
	    }	    }
	    

