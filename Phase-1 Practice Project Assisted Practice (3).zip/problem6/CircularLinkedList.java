package problem6;
import java.util.LinkedList;
import java.util.Scanner;
public class CircularLinkedList {


	
	    public static void main(String[] args) {
	        Scanner sc = new Scanner(System.in);

	        
	        LinkedList<Integer> list = new LinkedList<Integer>();

	     
	        System.out.print("Enter the size of the linked list: ");
	        int n = sc.nextInt();

	    
	        System.out.println("Enter the elements of the linked list in ascending order:");
	        for (int i = 0; i < n; i++) {
	            int data = sc.nextInt();
	            list.add(data);
	        }

	       
	        System.out.print("Enter the new element to be inserted: ");
	        int data = sc.nextInt();

	       
	        int index = 0;
	        while (index < list.size() && list.get(index) < data) {
	            index++;
	        }
	        list.add(index, data);

	     
	        list.addFirst(list.getLast());
	        list.removeLast();

	      
	        System.out.print("Modified Linked List: ");
	        for (int i = 0; i < list.size(); i++) {
	            System.out.print(list.get(i) + " ");
	        }
	        System.out.println();}
}

