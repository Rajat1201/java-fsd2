package problem7;

class Node {
    int data;
    Node prev;
    Node next;

    Node(int d) {
        data = d;
        prev = null;
        next = null;
    }
}

public class DoublyLinkedList {
    Node head;

    public void insert(int data) {
        Node newNode = new Node(data);

        if (head == null) {
            head = newNode;
            return;
        }

        Node curr = head;
        while (curr.next != null) {
            curr = curr.next;
        }

        curr.next = newNode;
        newNode.prev = curr;
    }

    public void traverseForward() {
        Node curr = head;

        System.out.print("Forward: ");
        while (curr != null) {
            System.out.print(curr.data + ", ");
            curr = curr.next;
        }
        System.out.println();
    }

    public void traverseBackward() {
        Node curr = head;

        if (curr == null) {
            return;
        }

        while (curr.next != null) {
            curr = curr.next;
        }

        System.out.print("Backward: ");
        while (curr != null) {
            System.out.print(curr.data + ", ");
            curr = curr.prev;
        }
        System.out.println();
    }

    public static void main(String[] args) {
        DoublyLinkedList list = new DoublyLinkedList();
        list.insert(1);
        list.insert(2);
        list.insert(3);
        list.insert(4);
        list.insert(5);
        list.insert(6);
        list.insert(7);
        list.insert(8);
        list.insert(9);
        list.insert(10);

        list.traverseForward();
        list.traverseBackward();
        
    }}
