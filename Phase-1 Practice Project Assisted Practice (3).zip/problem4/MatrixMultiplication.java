package problem4;
import java.util.Scanner;

public class MatrixMultiplication {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        System.out.print("Enter the number of rows of the first matrix: ");
        int row1 = sc.nextInt();
        System.out.print("Enter the number of columns of the first matrix: ");
        int col1 = sc.nextInt();
        System.out.print("Enter the number of rows of the second matrix: ");
        int row2 = sc.nextInt();
        System.out.print("Enter the number of columns of the second matrix: ");
        int col2 = sc.nextInt();

        if (col1 != row2) {
            System.out.println("The number of columns of the first matrix must be equal to the number of rows of the second matrix.");
            return;
        }

        int[][] firstMatrix = new int[row1][col1];
        int[][] secondMatrix = new int[row2][col2];

        System.out.println("Enter the elements of the first matrix:");
        for (int i = 0; i < row1; i++) {
            for (int j = 0; j < col1; j++) {
                firstMatrix[i][j] = sc.nextInt();
            }
        }

       
        System.out.println("Enter the elements of the second matrix:");
        for (int i = 0; i < row2; i++) {
            for (int j = 0; j < col2; j++) {
                secondMatrix[i][j] = sc.nextInt();
            }
        }

        
        int[][] resultMatrix = new int[row1][col2];
        for (int i = 0; i < row1; i++) {
            for (int j = 0; j < col2; j++) {
                for (int k = 0; k < col1; k++) {
                    resultMatrix[i][j] += firstMatrix[i][k] * secondMatrix[k][j];
                }
            }
        }

        System.out.println("The result matrix is:");
        for (int i = 0; i < row1; i++) {
            for (int j = 0; j < col2; j++) {
                System.out.print(resultMatrix[i][j] + " ");
            }
            System.out.println();}}
        
    
    
}		
 