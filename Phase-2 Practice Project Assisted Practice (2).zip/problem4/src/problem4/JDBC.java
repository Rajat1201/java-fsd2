package problem4;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Types;

public class JDBC {
    static final String JDBC_DRIVER = "com.mysql.cj.jdbc.Driver";
    static final String DB_URL = "jdbc:mysql://localhost/db2";
    static final String USER = "root";
    static final String PASS = "dgsdg454FF@";

    public static void main(String[] args) {
        Connection conn = null;
        CallableStatement cstmt = null;

        try {
           
            Class.forName(JDBC_DRIVER);

            
            System.out.println("Connecting to database...");
            conn = DriverManager.getConnection(DB_URL, USER, PASS);

         
            String createProcedure = "CREATE PROCEDURE sp(IN input_param VARCHAR(50), OUT output_param INT)\n" +
                                     "BEGIN\n" +
                                     "    DECLARE result INT;\n" +
                                     "    SET result = (SELECT COUNT(*) FROM employees WHERE name = input_param);\n" +
                                     "    SET output_param = result * 10;\n" +
                                     "END";
            Statement stmt = conn.createStatement();
            stmt.executeUpdate(createProcedure);

           
            System.out.println("Creating callable statement...");
            String storedProcedure = "{call sp(?, ?)}";
            cstmt = conn.prepareCall(storedProcedure);

           
            cstmt.setString(1, "Rajat");

       
            cstmt.registerOutParameter(2, Types.INTEGER);

       
            System.out.println("Executing stored procedure...");
            cstmt.execute();

         
            int result = cstmt.getInt(2);
            System.out.println("Result: " + result);

        } catch (SQLException se) {
           
            se.printStackTrace();
        } catch (Exception e) {
          
            e.printStackTrace();
        } finally {
           
            try {
                if (cstmt != null)
                    cstmt.close();
            } catch (SQLException se2) {
                se2.printStackTrace();
            }
            try {
                if (conn != null)
                    conn.close();
            } catch (SQLException se3) {
                se3.printStackTrace();
            }
        }
    }
}