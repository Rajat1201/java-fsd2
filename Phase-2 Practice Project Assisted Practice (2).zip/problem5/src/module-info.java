/**
 * 
 */
/**
 * @author Rajat Sharma
 *
 */
module problem5 {
	requires java.sql;
}