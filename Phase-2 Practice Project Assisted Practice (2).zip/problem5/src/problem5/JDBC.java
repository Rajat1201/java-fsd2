package problem5;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

public class JDBC {
    static final String JDBC_DRIVER = "com.mysql.cj.jdbc.Driver";
    static final String DB_URL = "jdbc:mysql://localhost/db3";
    static final String USER = "root";
    static final String PASS = "dgsdg454FF@";

    public static void main(String[] args) {
        Connection conn = null;
        Statement stmt = null;

        try {
           
            Class.forName(JDBC_DRIVER);

            
            System.out.println("Connecting to database...");
            conn = DriverManager.getConnection(DB_URL, USER, PASS);

            
            System.out.println("Creating database...");
            stmt = conn.createStatement();
            String createDatabase = "CREATE DATABASE db";
            stmt.executeUpdate(createDatabase);
            System.out.println("Database created successfully.");

            
            String useDatabase = "USE db";
            stmt.executeUpdate(useDatabase);
            System.out.println("Using database: db");

          
            System.out.println("Dropping database...");
            String dropDatabase = "DROP DATABASE db";
            stmt.executeUpdate(dropDatabase);
            System.out.println("Database dropped successfully.");

        } catch (SQLException se) {
           
            se.printStackTrace();
        } catch (Exception e) {
           
            e.printStackTrace();
        } finally {
           
            try {
                if (stmt != null)
                    stmt.close();
            } catch (SQLException se2) {
                se2.printStackTrace();
            }
            try {
                if (conn != null)
                    conn.close();
            } catch (SQLException se3) {
                se3.printStackTrace();
            }
        }
    }
}