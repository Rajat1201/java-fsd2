/**
 * 
 */
/**
 * @author Rajat Sharma
 *
 */
module problem6 {
	requires java.sql;
}