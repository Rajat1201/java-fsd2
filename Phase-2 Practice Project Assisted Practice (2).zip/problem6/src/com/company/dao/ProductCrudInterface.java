package com.company.dao;

import java.sql.SQLException;
import java.util.List;

import com.company.pojo.Product;

public interface ProductCrudInterface {
	
	public int addProduct(Product product) throws ClassNotFoundException, SQLException;

	public int deleteProduct(int id) throws ClassNotFoundException, SQLException;
	 
	public List<Product> selectProducts() throws ClassNotFoundException, SQLException;
	
	public int updateProductName(int id, String name) throws ClassNotFoundException, SQLException;
}

