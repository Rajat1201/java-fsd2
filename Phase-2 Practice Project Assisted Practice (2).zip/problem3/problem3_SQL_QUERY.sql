create database db;
USE db;
CREATE TABLE employees (
    id INT,
    name VARCHAR(100),
    age INT
);

INSERT INTO employees (id, name, age) VALUES (1, 'Rajat', 23);
INSERT INTO employees (id, name, age) VALUES (2, 'Rahul', 24);