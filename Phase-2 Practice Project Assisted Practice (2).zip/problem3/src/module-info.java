/**
 * 
 */
/**
 * @author Rajat Sharma
 *
 */
module problem3 {
	requires java.sql;
}