/**
 * 
 */
/**
 * @author Rajat Sharma
 *
 */
module problem1 {
	requires java.sql;
}