package com.example.entities;

import javax.persistence.Column;
import javax.persistence.Embeddable;

@Embeddable
public class Author {
    @Column(name = "author_name")
    private String name;

    // Getters and Setters

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}