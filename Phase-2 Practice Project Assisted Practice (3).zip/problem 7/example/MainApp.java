package com.example;

import com.example.entities.Author;
import com.example.entities.Book;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class MainApp {

    public static void main(String[] args) {

        // Create session factory
        Configuration configuration = new Configuration().configure();
        SessionFactory sessionFactory = configuration.buildSessionFactory();

        // Open session
        Session session = sessionFactory.openSession();

        try {
            // Create a book with author
            Book book = new Book();
            book.setTitle("Hibernate in Action");

            Author author = new Author();
            author.setName("John Doe");

            book.setAuthor(author);

            // Save the book
            Transaction transaction = session.beginTransaction();
            session.save(book);
            transaction.commit();

            // Close the session
            session.close();

            // Retrieve the book
            session = sessionFactory.openSession();
            Book retrievedBook = session.get(Book.class, book.getId());

            // Print the book details
            System.out.println("Book: " + retrievedBook.getTitle());
            System.out.println("Author: " + retrievedBook.getAuthor().getName());
        } finally {
            // Close the session and session factory
            session.close();
            sessionFactory.close();
        }
    }
}