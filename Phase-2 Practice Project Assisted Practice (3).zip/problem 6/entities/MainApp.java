package com.example.entities;

import com.example.entities.Author;
import com.example.entities.Book;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class MainApp {

    public static void main(String[] args) {

      
        Configuration configuration = new Configuration().configure();
        SessionFactory sessionFactory = configuration.buildSessionFactory();

       
        Session session = sessionFactory.openSession();

        try {
         
            Author author = new Author();
            author.setName("John Doe");

         
            Book book = new Book();
            book.setTitle("Hibernate in Action");
            book.setAuthor(author);

         
            Transaction transaction = session.beginTransaction();
            session.save(author);
            session.save(book);
            transaction.commit();

            
            session.close();

          
            session = sessionFactory.openSession();
            Book retrievedBook = session.get(Book.class, book.getId());

           
            Author retrievedAuthor = retrievedBook.getAuthor();

          
            System.out.println("Author: " + retrievedAuthor.getName());
        } finally {
            
            session.close();
            sessionFactory.close();
        }
    }
}