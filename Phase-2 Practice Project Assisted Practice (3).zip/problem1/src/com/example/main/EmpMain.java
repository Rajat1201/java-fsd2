package com.example.main;

import java.util.Scanner;



import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.boot.Metadata;
import org.hibernate.boot.MetadataSources;
import org.hibernate.boot.registry.StandardServiceRegistry;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;

import com.example.pojo.Employee;

public class EmpMain {
	public static void main(String[] args) {
		
		StandardServiceRegistry  ssr=new StandardServiceRegistryBuilder().configure("hibernate.cfg.xml").build();	
		
		Metadata md=new MetadataSources(ssr).getMetadataBuilder().build();
		
		SessionFactory sf=md.getSessionFactoryBuilder().build();
		
		Session s=sf.openSession();
	
		Transaction t=s.beginTransaction();
		Scanner sc=new Scanner(System.in);
		Employee e=new Employee();
		System.out.println("enter the eid");
		e.setEid(sc.nextInt());
		System.out.println("enter the ename");
		e.setEmpname(sc.next());
		System.out.println("enter the email");
		e.setEmpemail(sc.next());
		System.out.println("enter the salary");
		e.setSalary(sc.nextDouble());
		s.save(e);  //insert
		t.commit();
		s.close();
		sf.close();
		

}}
