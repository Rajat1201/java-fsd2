package com.example.com;

import com.example.entities.Employee;
import com.example.service.EmployeeService;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import java.util.List;

public class MainApp {

    public static void main(String[] args) {
        // Create Spring application context
        AnnotationConfigApplicationContext context = new AnnotationConfigApplicationContext(AppConfig.class);

        // Get EmployeeService bean from the context
        EmployeeService employeeService = context.getBean(EmployeeService.class);

        // Create and save a new employee
        Employee employee1 = new Employee();
        employee1.setName("John Doe");
        employee1.setAge(30);
        employeeService.saveEmployee(employee1);

        // Create and save another employee
        Employee employee2 = new Employee();
        employee2.setName("Jane Smith");
        employee2.setAge(28);
        employeeService.saveEmployee(employee2);

        // Get all employees
        List<Employee> employees = employeeService.getAllEmployees();
        System.out.println("All Employees:");
        for (Employee employee : employees) {
            System.out.println("ID: " + employee.getId() + ", Name: " + employee.getName() + ", Age: " + employee.getAge());
        }

        // Get an employee by ID
        Long employeeId = 1L;
        Employee retrievedEmployee = employeeService.getEmployeeById(employeeId);
        if (retrievedEmployee != null) {
            System.out.println("\nRetrieved Employee:");
            System.out.println("ID: " + retrievedEmployee.getId() + ", Name: " + retrievedEmployee.getName() + ", Age: " + retrievedEmployee.getAge());
        } else {
            System.out.println("\nEmployee not found with ID: " + employeeId);
        }

        // Update an employee
        if (retrievedEmployee != null) {
            retrievedEmployee.setName("Updated Employee");
            retrievedEmployee.setAge(35);
            employeeService.updateEmployee(retrievedEmployee);
            System.out.println("\nEmployee updated successfully.");
        }

        // Delete an employee
        Employee employeeToDelete = employeeService.getEmployeeById(2L);
        if (employeeToDelete != null) {
            employeeService.deleteEmployee(employeeToDelete);
            System.out.println("\nEmployee deleted successfully.");
        }

        // Close the context
        context.close();
    }
}