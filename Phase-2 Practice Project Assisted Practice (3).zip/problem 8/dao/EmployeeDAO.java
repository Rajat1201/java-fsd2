package com.example.dao;

import com.example.entities.Employee;

import java.util.List;

public interface EmployeeDAO {
    void save(Employee employee);

    Employee getById(Long id);

    List<Employee> getAll();

    void update(Employee employee);

    void delete(Employee employee);
}