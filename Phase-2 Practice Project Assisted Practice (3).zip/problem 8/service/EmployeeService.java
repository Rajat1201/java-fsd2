package com.example.service;

import com.example.entities.Employee;

import java.util.List;

public interface EmployeeService {
    void saveEmployee(Employee employee);

    Employee getEmployeeById(Long id);

    List<Employee> getAllEmployees();

    void updateEmployee(Employee employee);

    void deleteEmployee(Employee employee);
}