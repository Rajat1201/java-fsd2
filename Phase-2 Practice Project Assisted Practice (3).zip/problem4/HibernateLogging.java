package problem4;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class HibernateLogging {
    private static final Logger logger = LogManager.getLogger(HibernateLogging.class);

    public static void main(String[] args) {
        

        // Configure Hibernate
        Configuration configuration = new Configuration();
        configuration.configure("hibernate.cfg.xml"); // Assuming you have a hibernate.cfg.xml configuration file

        // Create a session factory
        SessionFactory sessionFactory = configuration.buildSessionFactory();

        // Open a session
        Session session = sessionFactory.openSession();

        try {
            
            Transaction transaction = session.beginTransaction();

            
            logger.info("Performing database operations...");

           

            transaction.commit();
            logger.info("Database operations completed successfully.");
        } catch (Exception e) {
            logger.error("An error occurred during database operations.", e);
        } finally {
            // Close the session
            session.close();

            // Close the session factory
            sessionFactory.close();
        }
    }
}