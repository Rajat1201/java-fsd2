create database problemstatement1;
use problemstatement1;

CREATE TABLE Book_Details (
    id INT PRIMARY KEY,
    book_title VARCHAR(255),
    book_publisher VARCHAR(255),
    book_isbn VARCHAR(255),
    book_number_of_pages INT,
    book_year INT
);

INSERT INTO Book_Details (id, book_title, book_publisher, book_isbn, book_number_of_pages, book_year)
VALUES
    (1, '.NET Core in Action', 'publisher1', '978-1-61729-427-3', 288, 2018),
    (2, '.NET Development Using the Compiler API', 'publisher2', '978-1-484221-10-5', 288, 2016),
    (3, '.Net Framework 4.5 Expert Programming Cookbook', 'publisher3', '978-1-84968-742-3', 176, 2013),
    (4, 'NET Framework Essentials, 2nd Edition', 'publisher4', '978-0-596-00302-9', 276, 2002),
    (5, '.NET IL Assembler', 'publisher2', '978-1-4302-6761-4', 320, 2014),
    (6, '.NET Standard 2.0 Cookbook', 'publisher3', '978-1-78883-466-7', 492, 2018),
    (7, '.NET Test Automation Recipes', 'publisher2', '978-1-59059-663-0', 394, 2006),
    (8, '10 LED Projects for Geeks', 'publisher2', '978-1-59327-825-0', 408, 2018),
    (9, '101 Design Ingredients to Solve Big Tech Problems', 'publisher5', '978-1-93778-532-1', 240, 2013),
    (10, '101 Excel 2013 Tips, Tricks and Timesavers', 'publisher6', '978-1-118-64218-4', 298, 2013),
    (11, '101 UX Principles', 'publisher5', '978-1-78883-736-1', 312, 2013),
    (12, '101 Windows Phone 7 Apps', 'publisher4', '978-0-672-33552-5', 414, 2018),
    (13, '20 Easy Raspberry Pi Projects', 'publisher2', '978-1-59327-843-4', 1152, 2011),
    (14, '20 Recipes for Programming MVC 3', 'publisher4', '978-1-4493-0986-2', 288, 2018),
    (15, '20 Recipes for Programming PhoneGap', 'publisher4', '978-1-4493-1954-0', 122, 2011),
    (16, '21 Recipes for Mining Twitter', 'publisher4', '978-1-4493-0316-7', 78, 2012),
    (17, '21st Century C', 'publisher4', '978-1-4493-2714-9', 72, 2011),
    (18, '21st Century C, 2nd Edition', 'publisher4', '978-1-49190-389-6', 50, 2011),
    (19, '21st Century Robot', 'publisher2', '978-1-44933-821-3', 296, 2012),
    (20, '25 Recipes for Getting Started with R', 'publisher4', '978-1-4493-0323-5', 408, 2014);
