package com.example.bookstore.service;

import com.example.bookstore.model.Book;
import com.example.bookstore.repository.BookStoreRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.List;

@Service
public class BookStoreService {
    @Autowired
    private BookStoreRepository bookStoreRepository;

    public List<Book> getAllBooks() {
        return bookStoreRepository.findAll();
    }

    public Book getBookById(Long id) {
        return bookStoreRepository.findById(id).orElse(null);
    }

    public Book addBook(Book book) {
        return bookStoreRepository.save(book);
    }

    public void updateBook(Book book) {
        bookStoreRepository.save(book);
    }

    public void deleteBook(Long id) {
        bookStoreRepository.deleteById(id);
    }

    public List<Book> searchByTitle(String title) {
        return bookStoreRepository.findByTitle(title);
    }

    public List<Book> searchByPublisher(String publisher) {
        return bookStoreRepository.findByPublisher(publisher);
    }

    public List<Book> searchByYear(int year) {
        return bookStoreRepository.findByYear(year);
    }
}
