package com.example.bookstore.controller;

import com.example.bookstore.model.Book;
import com.example.bookstore.service.BookStoreService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
@RequestMapping("/books")
public class BookStoreRestController {
    @Autowired
    private BookStoreService bookStoreService;

    @GetMapping
    public List<Book> getAllBooks() {
        return bookStoreService.getAllBooks();
    }

    @GetMapping("/{book_id}")
    public Book getBookById(@PathVariable("book_id") Long id) {
        return bookStoreService.getBookById(id);
    }

    @PostMapping
    public Book addBook(@RequestBody Book book) {
        return bookStoreService.addBook(book);
    }

    @PutMapping
    public void updateBook(@RequestBody Book book) {
        bookStoreService.updateBook(book);
    }

    @DeleteMapping("/{book_id}")
    public void deleteBook(@PathVariable("book_id") Long id) {
        bookStoreService.deleteBook(id);
    }

    @GetMapping("/title/{book_title}")
    public List<Book> searchByTitle(@PathVariable("book_title") String title) {
        return bookStoreService.searchByTitle(title);
    }

    @GetMapping("/publisher/{book_publisher}")
    public List<Book> searchByPublisher(@PathVariable("book_publisher") String publisher) {
        return bookStoreService.searchByPublisher(publisher);
    }

    @GetMapping(params = "year")
    public List<Book> searchByYear(@RequestParam("year") int year) {
        return bookStoreService.searchByYear(year);
    }
}
