package com;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EbookstoreappApplication {

	public static void main(String[] args) {
		SpringApplication.run(EbookstoreappApplication.class, args);
	}

}
