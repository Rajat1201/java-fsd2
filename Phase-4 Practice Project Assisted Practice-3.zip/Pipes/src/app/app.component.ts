import { Component } from '@angular/core';


@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
textdata="Raj"
salary=10000
date=new Date()
person={"name":"Raj","age":30}


}
