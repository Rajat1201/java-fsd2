import { Component, OnInit } from '@angular/core';
import { ServiceworkService } from '../servicework.service';

@Component({
  selector: 'app-about',
  templateUrl: './about.component.html',
  styleUrls: ['./about.component.css']
})
export class AboutComponent implements OnInit {
  constructor(private serviceobj:ServiceworkService) { }
  mobiles=this.serviceobj.mobile;


  addmobile(){
    this.serviceobj.mobile.push("samsung")
  }
  ngOnInit(): void {
  }

}
