import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class ServiceworkService {

  constructor() { }


  mobile=['redmi','realme','nokia']

}
