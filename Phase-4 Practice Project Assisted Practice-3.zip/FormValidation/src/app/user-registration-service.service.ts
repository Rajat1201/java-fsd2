import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class UserRegistrationServiceService {

  constructor(private http:HttpClient) { }

  //insert
public doregistration(user:any){
  return this.http.post("http://localhost:8088/register",user,{responseType:'text' as 'json'});
}

//get users
public getusers(){
  return this.http.get("http://localhost:8088/getAllusers");
}

//search by email
public getuserbyemail(email:any){
  return this.http.get("http://localhost:8088/findbyemail/"+email);
}

//delete by id
public deletebyid(id:any){
  return this.http.delete("http://localhost:8088/cancel/"+id);
}

public putuserbyid(id:number,user:any){ //method to send a put request to the backend API with the user id and data
  return this.http.put("http://localhost:8088/user/"+id,user); //put request with the user id and data
}
}




