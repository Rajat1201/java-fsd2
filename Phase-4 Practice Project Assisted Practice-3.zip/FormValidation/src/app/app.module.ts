import { NgModule, Component } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { RegistrationComponent } from './registration/registration.component';
import { SearchdeleteComponent } from './searchdelete/searchdelete.component';
import { RouterModule, Routes } from '@angular/router';
import { FormsModule } from '@angular/forms';
import {HttpClientModule} from '@angular/common/http'
import { UserRegistrationServiceService } from './user-registration-service.service';
const routes:Routes=[
{path:"",redirectTo:"register",pathMatch:"full"},
{path:"register",component:RegistrationComponent},
{path:"search",component:SearchdeleteComponent}

]
@NgModule({
  declarations: [
    AppComponent,
    RegistrationComponent,
    SearchdeleteComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    HttpClientModule,
    RouterModule.forRoot(routes)
  ],
  providers: [UserRegistrationServiceService],
  bootstrap: [AppComponent]
})
export class AppModule { }
