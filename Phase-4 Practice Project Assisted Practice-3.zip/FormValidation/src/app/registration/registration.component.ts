import { Component, OnInit } from '@angular/core';
import {User} from"../User"
import { UserRegistrationServiceService } from '../user-registration-service.service';
@Component({
  selector: 'app-registration',
  templateUrl: './registration.component.html',
  styleUrls: ['./registration.component.css']
})
export class RegistrationComponent implements OnInit{
user:User=new User();
constructor(private service:UserRegistrationServiceService){}
message=""
ngOnInit(): void{
}
public registerNow(){
  let response=this.service.doregistration(this.user);
  response.subscribe((data:any)=>this.message=data);
}
}