import { Component, OnInit } from '@angular/core';
import { UserRegistrationServiceService } from '../user-registration-service.service';


@Component({
  selector: 'app-searchdelete',
  templateUrl: './searchdelete.component.html',
  styleUrls: ['./searchdelete.component.css']
})
export class SearchdeleteComponent implements OnInit {


  email:any;
  users:any;
  userToUpdate:any;
  finduserbyemail(){
    let response=this.service.getuserbyemail(this.email);
    response.subscribe((data:any)=>this.users=data);
  }


  deleteuser(id:number){
    let response=this.service.deletebyid(id);
    response.subscribe((data:any)=>this.users=data);
  }
  constructor(private service:UserRegistrationServiceService) { }



  //by default if we dont need any function to be called then we need to write the code below
  ngOnInit(): void {
    let response=this.service.getusers();
    response.subscribe((data:any)=>this.users=data);
  }


  selectuser(id:number){ //method to select the user by id
    this.userToUpdate = this.users.find(user => user.id == id); //assign the user object with that id to the variable
  }

  updateuser(user:any){ //method to update the user by sending it to the service
    let response=this.service.putuserbyid(user.id,user); //call the service method with the user id and data
    response.subscribe((data:any)=>{
      this.users=data; //update the users array with the new data
      this.finduserbyemail(); //refresh the users array with the email filter
    }); 
  }

}
