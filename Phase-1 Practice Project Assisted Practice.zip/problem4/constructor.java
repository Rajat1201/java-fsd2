package problem4;

public class constructor {
	private int num1;
    private int num2;
    
    // Default constructor
    public constructor() {
        num1 = 0;
        num2 = 0;
    }
    
    // Parameterized constructor
    public constructor(int num1, int num2) {
        this.num1 = num1;
        this.num2 = num2;
    }
    
    // Copy constructor
    public constructor(constructor obj) {
        this.num1 = obj.num1;
        this.num2 = obj.num2;
    }
    
    // Getter methods
    public int getNum1() {
        return num1;
    }
    
    public int getNum2() {
        return num2;
    }
    
    public static void main(String[] args) {
        // Default constructor
        constructor obj1 = new constructor();
        System.out.println("Default constructor: " + obj1.getNum1() + ", " + obj1.getNum2());
        
        // Parameterized constructor
        constructor obj2 = new constructor(10,20);
        System.out.println("Parameterized constructor: " + obj2.getNum1() + ", " + obj2.getNum2());
        
        // Copy constructor
        constructor obj3 = new constructor(obj2);
        System.out.println("Copy constructor: " + obj3.getNum1() + ", " + obj3.getNum2());;
}}     
        

