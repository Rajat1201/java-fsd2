package problem7;

public class EgInnerClass {
	private String outerMessage = "Hello from outer class!";
	  
	  public void printOuterMessage() {
	    System.out.println(outerMessage);
	  }
	  
	  public class InnerClass {
	    
	    private String innerMessage = "Hello from inner class!";
	    
	    public void printInnerMessage() {
	      System.out.println(innerMessage);
	    }
	    
	    public void printOuterMessageFromInner() {
	      printOuterMessage();
	    }
	  }
	  
	  public static void main(String[] args) {
	    
	    
	    EgInnerClass outer = new EgInnerClass();
	    
	  
	    EgInnerClass.InnerClass inner = outer.new InnerClass();
	    
	   
	    inner.printInnerMessage();
	    inner.printOuterMessageFromInner();}
}  



	    
	  



