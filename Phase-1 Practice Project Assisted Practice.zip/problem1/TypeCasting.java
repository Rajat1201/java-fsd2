package problem1;

public class TypeCasting{
	public static void main(String[] args) { 
        // Implicit type casting
        int num1 = 8;
        double num2 = num1;
        System.out.println("Implicit type casting int to double: "+num2);
        
        // Explicit type casting
        double num3 =8.3;
        int num4 =(int) num3;
        System.out.println("Explicit type casting double to int: "+num4);}
}
