package problem9;

public class arrayim {
	    public static void main(String[] args) {
	        
	        int[] numbers = new int[5];

	       
	        numbers[0] = 1;
	        numbers[1] = 2;
	        numbers[2] = 3;
	        numbers[3] = 4;
	        numbers[4] = 5;
	        for (int i = 0; i < numbers.length; i++) {
	            System.out.println("Element " + i + " is " + numbers[i]);
	        }
	        String[] names = {"anny", "root", "jhonson"};

	        for (int i = 0; i < names.length; i++) {
	            System.out.println("Name "+i+" "+names[i]);;;;
	        }}}
	        
	    
	    
	    
	    
	    
        
	            
	            
	            
	            
	            
	            
	            
	            
	            
	            
	            
	            
	            
	            
	            
	        	            
	    