package problem10;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class RegularExpression {
	 public static void main(String[] args) {
		    
		   //pattern for matching URLs
		    String patternString = "^(https?|ftp)://[a-z0-9.-]+\\.[a-z]{2,}$";
		    Pattern pattern = Pattern.compile(patternString);
		    
		    //some sample URLs
		    String[] urls = {"http://www.company.com", "https://company.net", "ftp://ftp.company.org", "invalid-url", "http://company"};
		    
		    // iterate over the URLs 
		    for (String url : urls) {
		      Matcher matcher = pattern.matcher(url);
		      if (matcher.matches()) {
		        System.out.println(url + " is a valid URL.");
		      } else {
		        System.out.println(url + " is not a valid URL.");
		        
		      
		      }}}
}
		    
		    
		    
	 
