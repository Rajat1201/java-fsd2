package problem2;

public class AccessModifier {




	public static void main(String[] args) {
        student student = new student("Aniket", "Tyagi",18,143066);
        System.out.println("Name: " + student.getFullName()); 
        System.out.println("Age: " + student.age);
        System.out.println("Roll Number :" + student.roll_no); 
    }
}

class student {
    private String firstName; // private instance variable
    private String lastName;
    public int roll_no;// public instance variable
    public int age; // public instance variable
    
    public student(String firstName, String lastName, int age,int roll_no) {
        this.firstName = firstName;
        this.lastName = lastName;
        this.age = age;
        this.roll_no=roll_no;
    }
    
    public String getFullName() { // public method to access private variables
        return firstName + " " + lastName;
    }}        
        
        


