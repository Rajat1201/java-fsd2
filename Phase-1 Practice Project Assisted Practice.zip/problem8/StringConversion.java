package problem8;

public class StringConversion {
  public static void main(String[] a)
  {
    String myString = "Hello, world!";
    
   
    StringBuffer myStringBuffer = new StringBuffer(myString);
    
  
    StringBuilder myStringBuilder = new StringBuilder(myString);
    
  
    System.out.println("Original String: " + myString);
    
    // StringBuffer
    System.out.println("StringBuffer: " + myStringBuffer);
    
    // StringBuilder
    System.out.println("StringBuilder: " + myStringBuilder);
}}
