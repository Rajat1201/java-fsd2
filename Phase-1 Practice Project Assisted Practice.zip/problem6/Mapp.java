package problem6;
import java.util.HashMap;
import java.util.Map;

public class Mapp {
	public static void main(String[] a)
	 {
		
	     Map<String, Integer> map = new HashMap<>();

	    
	     map.put("Akash", 10);
	     map.put("Bansi", 20);
	     map.put("Chandu", 30);

	    
	     int AkashAge = map.get("Akash");
	     System.out.println("Akash's age is " + AkashAge);

	     
	     boolean containsKey = map.containsKey("Chandu");
	     System.out.println("Map contains Chandu? " + containsKey);

	     
	     for (String key : map.keySet()) {
	         int value = map.get(key);
	         System.out.println(key + " is " + value + " years old");
	     }

	     
	     map.remove("Bansi");

	     
	     int size = map.size();
	   
	     System.out.println("Map size is"+size);
	 
	 }
	

}
	 
	 
	