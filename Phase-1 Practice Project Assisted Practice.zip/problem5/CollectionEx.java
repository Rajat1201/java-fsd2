package problem5;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedList;

public class CollectionEx {
	 public static void main(String[] args) {
	        // ArrayList 
	        ArrayList<String> list = new ArrayList<>();
	        list.add("arr1");
	        list.add("arr2");
	        list.add("arr3");
	        System.out.println("ArrayList example: " + list);
	        
	
	        // HashSet 
	        HashSet<Integer> set = new HashSet<>();
	        set.add(10);
	        set.add(20);
	        set.add(30);
	        set.add(30); 
	        System.out.println("HashSet example: " + set);
	        
	        // LinkedList 
	        LinkedList<Integer> linkedList = new LinkedList<>();
	        linkedList.add(10);
	        linkedList.add(20);
	        linkedList.add(30);
	        System.out.println("LinkedList example: " + linkedList);
	        
	        // HashMap 
	        HashMap<String, Integer> map = new HashMap<>();
	        map.put("Orange", 10);
	        map.put("Red", 20);
	        map.put("Blue", 30);
	        System.out.println("HashMap example"+map);
	        }}	        
	        
	        
	        