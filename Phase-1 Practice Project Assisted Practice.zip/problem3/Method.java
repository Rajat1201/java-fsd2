package problem3;

public class Method{
	    public static void main(String[] a) {
	        // Calling a static method
	        int result1 = sum(10,20);
	        System.out.println("Result of sum() static method: " + result1);
	        
	        // Calling an instance method
	        Method obj = new Method();
	        int result2 = obj.multiply(10,20);
	        System.out.println("Result of multiply() Instance method: " + result2);
	    }
	    
	    // Static method
	    public static int sum(int num1, int num2) {
	        return num1 + num2;}
	    
	    
	    // Instance method
	    public int multiply(int num1, int num2) {
	        return num1 * num2;
	    }}

