package com.ecommerce.test;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Action;
import org.openqa.selenium.interactions.Actions;

public class Actions {
	
	public static void main(String[] args) throws InterruptedException {
		
		WebDriver driver = new ChromeDriver();
		
		demoDoubleClick(driver);

	}

	static void demoDoubleClick(WebDriver driver) throws InterruptedException {

		String baseUrl = "File:///C:\\Users\\Rajat\\eclipse-workspace\\1\\src\\main\\resources\\test.html";
		driver.get(baseUrl);

		
				Thread.sleep(10000);
				
				WebElement button = driver.findElement(By.id("dblButton"));
				
				
				Actions actions = new Actions(driver);
				actions.doubleClick(button).perform();
				
				Thread.sleep(10000);
				
				Thread.sleep(5000);
				WebElement helloPara = driver.findElement(By.id("xyz"));
				Actions multiActions = new Actions(driver);
				
			
				
				Actions multiActions2 = new Actions(driver);
				Action action2 = multiActions2
				.moveToElement(button)
				.click(button)
				.pause(1000)
				.moveToElement(helloPara)
				.pause(2000)
				.doubleClick(helloPara)
				.release()
				.build();
				
				action2.perform();
				
			
				Thread.sleep(2000);
				Actions scrollPageActions = new Actions(driver);
				scrollPageActions
				.sendKeys(Keys.PAGE_DOWN)
				.sendKeys(Keys.PAGE_DOWN)
				.pause(5000)
				.sendKeys(Keys.PAGE_UP)
				.build()
				.perform();
	}

}