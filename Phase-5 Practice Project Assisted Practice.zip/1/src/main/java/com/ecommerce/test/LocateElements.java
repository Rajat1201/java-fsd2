package com.ecommerce.test;

import org.openqa.selenium.*;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;


public class LocateElements {
	
	public static void main(String[] args) throws InterruptedException {

				WebDriver driver = new ChromeDriver();
				
			
				facebookAccCreation(driver);
	}


	public static void facebookAccCreation(WebDriver driver) throws InterruptedException {
		String baseUrl = "https://www.facebook.com/r.php?locale=en_GB&display=page";
		
		driver.get(baseUrl);
		
		WebElement firstNameTF = driver.findElement(By.name("firstname"));
		firstNameTF.sendKeys("abhi");
		
		
		
		String fullXPathOfDayDropDown = 
				"/html/body/div[1]/div[1]/div[1]/div[2]/div/div[2]/div/div/div[1]/form/div[1]/div[5]/div[2]/span/span/select[1]";
		WebElement dayDropDown = driver.findElement(By.xpath(fullXPathOfDayDropDown));
		
		Select select = new Select(dayDropDown);
		select.selectByVisibleText("11");
		
		
		String monthXpath = "/html/body/div[1]/div[1]/div[1]/div[2]/div/div[2]/div/div/div[1]/form/div[1]/div[5]/div[2]/span/span/select[2]";
		WebElement monthDropDown = driver.findElement(By.xpath(monthXpath));
		Select select1 = new Select(monthDropDown);
		select1.selectByVisibleText("Oct");
		
	
		WebElement fbLogoImage = driver.findElement(By.tagName("img"));
		System.out.println("FB Logo src is "+fbLogoImage.getAttribute("src"));
		
		
		WebElement fbAlreadyLink = driver.findElement(By.linkText("Already have an account?"));
		fbAlreadyLink.click();
		

	}
	
	public static void googleAccCreation(WebDriver driver) throws InterruptedException {
						
				String baseUrl = "https://accounts.google.com/signup/v2/createaccount?flowEntry=SignUp";
				
				driver.get(baseUrl);
				
			
				WebElement firstNameTF = driver.findElement(By.id("firstName"));				
								
				firstNameTF.sendKeys("firname");
				
				
				WebElement lastNameTF = driver.findElement(By.name("lastName"));				
				lastNameTF.sendKeys("lasname");
			
				WebElement nextButton = driver.findElement(By.className("VfPpkd-vQzf8d"));
				nextButton.click();	
				
			
				String xPathOfMonth = "/html/body/div[1]/div[1]/div[2]/div/div[2]/div/div/div[2]/div/div[1]/div/form/span/section/div/div/div[1]/div[2]/div/div/div[2]/select";
				WebElement monthSelectElement = driver.findElement(By.xpath(xPathOfMonth));
				System.out.println("monthSelectElement details "+monthSelectElement);	
				
				Select select = new Select(monthSelectElement);
				select.selectByValue("6");	
				

				Thread.sleep(15000);				
				driver.close();

	}

}