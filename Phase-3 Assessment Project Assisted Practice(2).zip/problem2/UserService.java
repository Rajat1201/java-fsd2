package problem2;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

@Service
public class UserService {

    @Value("${api.base.url}")
    private String baseUrl;

    public Employee getEmployeeById(int employeeId) {
        String url = baseUrl + "/employees/" + employeeId;
        RestTemplate restTemplate = new RestTemplate();
        ResponseEntity<Employee> response = restTemplate.getForEntity(url, Employee.class);
        return response.getBody();
    }
}