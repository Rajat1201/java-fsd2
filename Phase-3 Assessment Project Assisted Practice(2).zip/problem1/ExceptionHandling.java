package problem1;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.bind.annotation.RequestMapping;

@SpringBootApplication
public class ExceptionHandling {

    public static void main(String[] args) {
        SpringApplication.run(ExceptionHandling.class, args);
    }
}

@RestController
class HelloController {

    @RequestMapping("/")
    public String hello() {
        // Simulating an exception
        throw new CustomException("This is a custom Exception");
    }
}

@ControllerAdvice
class GlobalExceptionHandler {

    @ExceptionHandler(CustomException.class)
    public String handleCustomException(CustomException ex) {
        return "Custom Exception handled: " + ex.getMessage();
    }

    @ExceptionHandler(Exception.class)
    public String handleGeneralException(Exception ex) {
        return "General Exception handled: " + ex.getMessage();
    }
}

class CustomException extends RuntimeException {

    public CustomException(String message) {
        super(message);
    }
}
