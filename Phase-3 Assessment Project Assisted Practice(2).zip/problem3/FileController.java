package problem3;

import org.springframework.stereotype.Controller;
import org.springframework.util.FileCopyUtils;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import javax.servlet.http.HttpServletResponse;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;

@Controller
public class FileController {

    @GetMapping("/")
    public String index() {
        return "index";
    }

    @PostMapping("/upload")
    public @ResponseBody String handleFileUpload(@RequestParam("file") MultipartFile file) {
        if (!file.isEmpty()) {
            try {
                byte[] bytes = file.getBytes();
                File uploadedFile = new File(file.getOriginalFilename());
                BufferedOutputStream stream = new BufferedOutputStream(new FileOutputStream(uploadedFile));
                stream.write(bytes);
                stream.flush();
                stream.close();
                return "File uploaded successfully!";
            } catch (IOException e) {
                return "Error uploading file: " + e.getMessage();
            }
        } else {
            return "No file selected!";
        }
    }

    @GetMapping("/download")
    public void handleFileDownload(HttpServletResponse response) throws IOException {
        String fileName = "doc1.txt"; 
        File file = new File(fileName);
        response.setContentType("application/octet-stream");
        response.setHeader("Content-Disposition", "attachment; filename=" + fileName);
        response.setContentLength((int) file.length());
        FileCopyUtils.copy(FileCopyUtils.copyToByteArray(file), response.getOutputStream());
    }
}