package problem3;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.jdbc.core.JdbcTemplate;

public class JdbcSpringIntegration {
    public static void main(String[] args) {
       
        ApplicationContext context = new ClassPathXmlApplicationContext("applicationContext.xml");

        
        JdbcTemplate jdbcTemplate = context.getBean(JdbcTemplate.class);

      
        String sql = "SELECT * FROM books";
        jdbcTemplate.query(sql, rs -> {
            int id = rs.getInt("id");
            String title = rs.getString("title");
            String author = rs.getString("author");
            double price = rs.getDouble("price");

            System.out.println("Book ID: " + id);
            System.out.println("Book Title: " + title);
            System.out.println("Book Author: " + author);
            System.out.println("Book Price: " + price);
           
        });
    }
}
