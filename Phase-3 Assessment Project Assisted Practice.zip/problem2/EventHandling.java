package problem1;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class EventHandling {
    public static void main(String[] args) {
        
        JFrame frame = new JFrame("Event Handling");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(400, 300);

        
        JButton button = new JButton("Click Me");
        
       
        button.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                System.out.println("Button Clicked-Default Event Handler");
            }
        });

        
        button.addMouseListener(new MouseAdapter() {
            public void mouseClicked(MouseEvent e) {
                System.out.println("Button Clicked-Custom Event Handler");
            }
        });

        
        frame.getContentPane().add(button, BorderLayout.CENTER);

      
        frame.setVisible(true);
    }
}
