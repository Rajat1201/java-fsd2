package MavenSpring.Springdemo;

public class Idea implements Sim{
	public void typeOfSim()
	{
		System.out.println("Idea is the Sim");
	}
	 public void dataTypeOfSim()
	 {
		 System.out.println("4g network");
	 }
}
