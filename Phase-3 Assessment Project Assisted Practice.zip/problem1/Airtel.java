package MavenSpring.Springdemo;

public class Airtel implements Sim{

	public void typeOfSim()
	{
		System.out.println("Airtel is the Sim");
	}
	 public void dataTypeOfSim()
	 {
		 System.out.println("5g network");
	 }
}
