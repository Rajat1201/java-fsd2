package MavenSpring.Springdemo;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class SimMain {
public static void main(String[] a)
{
	ApplicationContext ac=new ClassPathXmlApplicationContext("Spring.xml");
	Airtel airtel=ac.getBean(Airtel.class);
	airtel.dataTypeOfSim();
	airtel.typeOfSim();
	
}
}
